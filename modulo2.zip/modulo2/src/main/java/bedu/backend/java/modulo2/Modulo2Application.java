package bedu.backend.java.modulo2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Modulo2Application {

	public static void main(String[] args) {
		SpringApplication.run(Modulo2Application.class, args);
	}

}
